---
name: 魚機私服連結轉跳
description: >
  Use this skill when the user wants to open a fish game private server URL,
  connect to a test/dev environment, or generate a game launch link.
  Triggers on phrases like "幫我開"、"開私服"、"連接遊戲"、"開測試連結".
version: "1.0"
author: IGS
---

# 魚機私服連結轉跳 (SifuLink)

Use this skill when the user wants to open a fish game private server URL, connect to a test/dev environment, or generate a game launch link.

## How to use

### Step 1 — Ask the user for any missing parameters

Required parameters:
- `account` — player account (e.g. `poc0001`)
- `game` — game code (see list below)

Optional (use defaults if not specified):
- `client` — client IP option name (default: `Client - ICE`)
- `server` — server IP option name (default: `DEV - Cross(macross-dev)`)
- `lang` — language, `en-us` or `zh-cn` (default: `en-us`)
- `port` — client port (default: `7456`)

### Step 2 — Call the API

```
GET http://localhost:5487/api/open_link?client={client}&server={server}&account={account}&game={game}&lang={lang}&port={port}
```

URL-encode spaces as `+` or `%20` in option names.

The service will open the browser on the user's machine and return JSON:
```json
{ "url": "http://..." }
```

### Available Client / Server IP options

| Option name | IP |
|---|---|
| Client - ICE | 192.168.121.37 |
| Client - JANE | 192.168.121.192 |
| Client - LEAVI | 192.168.121.115 |
| Client - DING | 192.168.121.74 |
| Client - C JER | 192.168.121.150 |
| Client - GOUWEI | 192.168.123.121 |
| Client - PAULO | 192.168.121.108 |
| Client - KIDD | 192.168.132.71 |
| Both - STEVELEE | 192.168.121.48 |
| SERVER - POC | 192.168.121.86 |
| SERVER - KUO | 192.168.121.139 |
| SERVER - SIMONWEI | 192.168.132.70 |
| PAN | 192.168.121.45 |
| DEV - 50 | 192.168.121.50 |
| DEV - 142 | 192.168.121.142 |
| DEV - Cross(macross-dev) | 35.198.231.50 |

### Available games

| Code | Display name | Type |
|---|---|---|
| ZombieAwaken | 惡靈覺醒 | 魚機 |
| LuckyBuddha | 彌勒佛 | 魚機 |
| MrFortune | 至尊財神 | 魚機 |
| MoneyTree | 搖錢樹 | 魚機 |
| IceFire | 冰焰龍戰 | 魚機 |
| AladdinAdventure | 阿拉丁冒險 | 魚機 |
| Circus | 馬戲團 | 魚機 |
| SuperStar | 明星派對 | 魚機 |
| OceanParadise | 海洋開拓者 | 魚機 |
| AgeOfFrost | 泰坦冰紀元 | 魚機 |
| CatFish | 功夫喵 | 魚機 |
| JackpotFrenzy | 彩金狂飆 | 魚機 |
| RagingDragonDeluxe | 炙焰魔龍 | 魚機 |
| AladdinMirage | 阿拉丁2 | 魚機 |
| GoldenBuffalo | 野牛 | 魚機 |
| TycoonLegends | 富豪傳說 | 魚機 |
| PiggyFortunes | 三隻小豬 | 魚機 |
| ChampionShot | 冠軍射門 | 魚機 |
| Mummy | 木乃伊 | 魚機 |
| SkyKing | 雷霆戰機 | 類魚 |
| HalloweenParty | 萬聖派對 | 類魚 |
| GhostHunters | 魔鬼剋星 | 類魚 |
| SuperStarHighRoller | 明星派對高廳館 | 高分 |
| CatFishHighRoller | 功夫喵高廳館 | 高分 |
| AladdinMirageHighRoller | 阿拉丁2高廳館 | 高分 |
| TycoonLegendsHighRoller | 富豪傳說高廳館 | 高分 |
| SkyKingHighRoller | 雷霆戰機高廳館 | 類魚 |

## Examples

**User:** 幫我開 ICE 的 AladdinMirage，帳號 poc0001  
**Call:** `GET http://localhost:5487/api/open_link?client=Client+-+ICE&server=DEV+-+Cross%28macross-dev%29&account=poc0001&game=AladdinMirage&lang=en-us`

**User:** 開 KIDD 的 SkyKing，帳號 test001，語言中文  
**Call:** `GET http://localhost:5487/api/open_link?client=Client+-+KIDD&server=DEV+-+Cross%28macross-dev%29&account=test001&game=SkyKing&lang=zh-cn`

**User:** 幫我開 STEVELEE 